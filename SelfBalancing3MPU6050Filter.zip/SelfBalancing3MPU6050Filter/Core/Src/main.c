/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>
#include<string.h>
#include<math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TRUE 1

#define ENC_COUNT_REV 11  //my encoder has 11 couts per revolution

#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))

//for MPU6050
#define MPU6050_ADDR		0xD0

#define	SMLRT_DIV_REG		0x19
#define GYRO_CONFIG_REG		0x1B
#define ACCEL_CONFIG_REG	0x1C
#define ACCEL_XOUT_H_REG	0x3B
#define TEMP_OUT_H_REG		0x41
#define GYRO_XOUT_H_REG		0x43
#define PWR_MGMT_1_REG		0x6B
#define WHO_AM_I_REG		0x75
#define TEMP_OUT_H_REG		0x41

#define PI	3.1415926
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim15;

UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_usart1_rx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM15_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int encoder1PulseCntr,encoder2PulseCntr; //pulse counter for encoder
int M1rpm,M2rpm; //rmp measurement
uint8_t M1dir,M2dir; //store the direction of the motor
char uartBuffer[50];

uint16_t tickCntr = 0;
char CntrMsg[100] = {'\0'}; ;


uint8_t rxIndex;		//
uint8_t Transfer_Complete;	//show that trasfer has completed. Not used in this project but could be handy in the program where the main processor may require the use of uart rx data
char rxData[2];
char rxBuffer[50];

void runTwoMotorTest(void)
{
	/*The two motor are connected with PWM for one motor provided
	 * on Pin PA2 (TIM15_CH1) and the motor switching pins for this
	 * motor are PA15 (M1_IN1) and PB3 (M1_IN2).
	 *
	 * The PWM for the second motor is provided on Pin PA3 (TIM15_CH2)
	 * and the motor switching pins for this motor are PB4 (M2_IN3) and
	 * PB5 (M2_IN4)
	 */

	/*First I will drive the motor in one direction with a constant PWM
	  signal set two 70%
	  */
	/* Now drive motor A in one direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	M1dir = 1;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in one direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	M2dir = 1;
	htim15.Instance->CCR2 = 50;
	HAL_Delay(2000);

	/* Now STOP motor A*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	htim15.Instance->CCR1 = 0;

	/*Now STOP motor B*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	htim15.Instance->CCR2 = 0;
	HAL_Delay(2000);

	/* Now drive motor A in the opposite direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET); //M1_IN2
	M1dir = 0;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in the opposite direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET); //M2_IN4
	M2dir = 0;
	htim15.Instance->CCR2 = 50;
	HAL_Delay(2000);

	/* Now STOP motor A*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	htim15.Instance->CCR1 = 0;

	/*Now STOP motor B*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	htim15.Instance->CCR2 = 0;

	HAL_Delay(2000);
}

void runTwoMotorTestVariablePWMDuty(void)
{
	/*The two motor are connected with PWM for one motor provided
	 * on Pin PA2 (TIM15_CH1) and the motor switching pins for this
	 * motor are PA15 (M1_IN1) and PB3 (M1_IN2).
	 *
	 * The PWM for the second motor is provided on Pin PA3 (TIM15_CH2)
	 * and the motor switching pins for this motor are PB4 (M2_IN3) and
	 * PB5 (M2_IN4)
	 */

	/*This function will run the motors with a variable PWM duty cycle.
	 * First incrementing the duty cycle and then reducing the duty
	 * cycle will bring the motors to halt.
	 */
	/* Now drive motor A in one direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET); //M1_IN2
	M1dir = 1;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in one direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET); //M2_IN4
	M2dir = 1;
	htim15.Instance->CCR2 = 50;
	//HAL_Delay(2000);

	for(int i = 0;i<100;i++)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
		HAL_Delay(100);
	}
	HAL_Delay(1000);

	for(int i = 100;i>0;i--)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
	}
	HAL_Delay(2000);

	/* Now drive motor A in the opposite direction*/
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET); //M1_IN1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET); //M1_IN2
	M1dir = 0;
	htim15.Instance->CCR1 = 50;

	/* Now drive motor B in the opposite direction*/
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //M2_IN3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET); //M2_IN4
	M2dir = 0;
	htim15.Instance->CCR2 = 50;

	for(int i = 0;i<100;i++)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
		HAL_Delay(100);
	}
	HAL_Delay(1000);

	for(int i = 100;i>0;i--)
	{
		htim15.Instance->CCR1 = i;
		htim15.Instance->CCR2 = i;
	}
	HAL_Delay(2000);
}




int16_t Accel_X_RAW = 0;
int16_t Accel_Y_RAW;
int16_t Accel_Z_RAW;

int16_t Gyro_X_RAW;
int16_t Gyro_Y_RAW;
int16_t Gyro_Z_RAW;

int16_t TempValue_RAW;

//double Ax,Ay,Az;
//double Gx,Gy,Gz;
float Ax, Ay, Az, Gx, Gy, Gz, TempOut;
char uartTxBuffer[200];

//char uartBuffer[200];   //used for UART transmission


void MPU6050_init(void)
{
	uint8_t check, data;

	/*1. Check if the sensor is present (working) by reading the "WHO_AM_I (0x75)" register.
	 *    The sensor should return 0x68 (104)*/
	//check device ID WHO_AM_I
	HAL_I2C_Mem_Read(&hi2c1,MPU6050_ADDR,WHO_AM_I_REG,1,&check,1,1000);

	if(check == 104)
	{
		/*2. The next step is to wake the sensor up. To do this, we have to write "0x00 (value) to the "PWR_MGMT_1 (0x6B)" register*/
		data = 0;
		HAL_I2C_Mem_Write(&hi2c1,MPU6050_ADDR,PWR_MGMT_1_REG,1,&data,1,1000);
		/*3. Now we need to set the data output rate or sample rate by writing the "SMPLRT_DIV (0x19)" register.
		 * For the sample rate of 1kHz, the value should be "7" */
		data = 0x07;
		HAL_I2C_Mem_Write(&hi2c1,MPU6050_ADDR,SMLRT_DIV_REG,1,&data,1,1000);
		/*4. Next we need to configure the full scale range of accelerometer and gyroscope, so I will write 0x00 to "GYRO_CONFIG_reg (0x1b"
		 * and "ACCEL_CONFIG_REG (0X1C" registers*/
		//Set gyroscopic configuration in GYRO_CONFIG register
		//XG_ST = 0,YG_ST= 0, ZG_ST = 0, FS_SEL = 0 -> ±250 °/S
		data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1,MPU6050_ADDR,GYRO_CONFIG_REG,1,&data,1,1000);

		//Set accelerometer configuration in ACCEL_CONFIG register
		//XA_ST=0, YA_ST= 0, ZA_ST=0, FS_SEL=0 ->±2g
		data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1,MPU6050_ADDR,ACCEL_CONFIG_REG,1,&data,1,1000);
	}
}

/*To read the accelerometer data, we need to read 6 bytes from the "ACCEL_XOUT_H (0x3B)" register
 * The data output for each axis will require 16bits integer (uint16_t).
 *
 * So we need to combine these 6 bytes integers value.
 * Below is the process to do that:-
 *
 * ACCEL_X = (ACCEL_XOUT_H<<8 | ACCEL_OUT_L)
 *
 * So We are shifting the high 8 bits to the left and then 'OR' it with the lower 8 bits.
 * For Example, if ACCEL_OUT_H = 11101110 and ACCEL_OUT_L = 10101010
 *
 * We should expect the resultant 16bits value as:
 * ACCEL_XOUT = 1110111010101010
 */

/*
 * Remember, in the initialisation, we set up the full scale for accelerometer as ±2g and
 * for Gyroscope it was set to ±250 °/S.
 * Now according to the datasheet, for the full scale of ±2g, the sensitivity is given as 16384 LSB/g
 * This means that we need to divide our RAW values by 16384.0 in order to get acceleration in 'g'. Using the decimal 0 (.0) is
 * important or else you are not going to get floating values.
 *
 * Similarly, for the gyroscope, for the full scale of ±250 °/S, the sensitivity is given as 131 LSB/dps so divide the RAW
 * values by 131.0.
 */
void MPU6050_Read_Accel(void)
{
	uint8_t Rec_Data[6];
	//Read 6 bytes of data starting from ACCEL_XOUT_H register
	HAL_I2C_Mem_Read(&hi2c1,MPU6050_ADDR,ACCEL_XOUT_H_REG,1,&Rec_Data,6,1000);

	Accel_X_RAW = (int16_t)(Rec_Data[0]<<8 | Rec_Data[1]); //cast to signed values
	Accel_Y_RAW = (int16_t)(Rec_Data[2]<<8 | Rec_Data[3]);
	Accel_Z_RAW = (int16_t)(Rec_Data[4]<<8 | Rec_Data[5]);

	/*
	 * Converting RAW value into acceleration in 'g', we have to divide according to the
	 * full scale value set in FS_SEL. I have configured FS_SEL =0, thus I am dividing by 16384.0
	 * for more information check the ACCEL_CONFIG register in the datasheet.
	 */
	Ax = Accel_X_RAW/16384.0;
	Ay = Accel_Y_RAW/16384.0;
	Az = Accel_Z_RAW/16384.0;
}

void MPU6050_Read_Gyro(void)
{
	uint8_t Rec_Data[6];
	//Read 6 bytes of data starting from GYRO_XOUT_H register
	HAL_I2C_Mem_Read(&hi2c1,MPU6050_ADDR,GYRO_XOUT_H_REG,1,&Rec_Data,6,1000);

	Gyro_X_RAW = (int16_t)(Rec_Data[0]<<8 | Rec_Data[1]);  //cast to signed values
	Gyro_Y_RAW = (int16_t)(Rec_Data[2]<<8 | Rec_Data[3]);
	Gyro_Z_RAW = (int16_t)(Rec_Data[4]<<8 | Rec_Data[5]);

	/*
	 * Converting the RAW values into dps (°/S) we have to divide according to the full scale set in FS_SEL.
	 * I have configured FS_SEL=0, thus i am going to divide by 131.0
	 * for more details, see GYRO_CONFIG Register
	 */

	Gx = Gyro_X_RAW/131.0;
	Gy = Gyro_Y_RAW/131.0;
	Gz = Gyro_Z_RAW/131.0;
}

/*
 * NEXT: we need to convert these RAW accelerometer values into 'g'
 * and these RAW gyroscope value into dps (°/s)*/



/*
 * MPU6050_Read_Temperature() read the temperature from the sensor (i.e. MPU6050) and does the calculation that converts
 * the raw values into degree celsius.
 */
void MPU6050_Read_Temperature(void)
{
	uint8_t Raw_TempData[2];
	//Read 6 bytes of data starting from TEMP_OUT_H_REG register
	HAL_I2C_Mem_Read(&hi2c1,MPU6050_ADDR,TEMP_OUT_H_REG,1,&Raw_TempData,2,1000);

	TempValue_RAW = (int16_t)Raw_TempData[0]<<8 | Raw_TempData[1];


	/*
	 * The temperature in degrees C for a given register value may be computed as:
	 * Temperature in degrees C = (TEMP_OUT Register Value as a signed quantity)/340 + 36.53
	 */

	TempOut = (TempValue_RAW/340.0)+36.53;
}


//This function have to be called by reference.
//void MPU6050_ReadAllSixMotions(int16_t *ax, uint16_t *ay, uint16_t *az, uint16_t *gx, uint16_t *gy, uint16_t *gz)
void MPU6050_ReadAllSixMotions(int16_t *ax, int16_t *ay, int16_t *az, int16_t *gx, int16_t *gy, int16_t *gz)
{
	//MPU6050_Read_Accel
	uint8_t Rec_Data[6];
	//Read 6 bytes of data starting from ACCEL_XOUT_H register
	HAL_I2C_Mem_Read(&hi2c1,MPU6050_ADDR,ACCEL_XOUT_H_REG,1,&Rec_Data,6,1000);

	*ax = (int16_t)(Rec_Data[0]<<8 | Rec_Data[1]); //cast to signed values
	*ay = (int16_t)(Rec_Data[2]<<8 | Rec_Data[3]);
	*az = (int16_t)(Rec_Data[4]<<8 | Rec_Data[5]);

	for(int x =0;x<6;x++)  //clear the Rec_Data
	{
		Rec_Data[x]=0;
	}

	//MPU6050_Read_Gyro
	//Read 6 bytes of data starting from GYRO_XOUT_H register
	HAL_I2C_Mem_Read(&hi2c1,MPU6050_ADDR,GYRO_XOUT_H_REG,1,&Rec_Data,6,1000);

	*gx = (int16_t)(Rec_Data[0]<<8 | Rec_Data[1]);  //cast to signed values
	*gy = (int16_t)(Rec_Data[2]<<8 | Rec_Data[3]);
	*gz = (int16_t)(Rec_Data[4]<<8 | Rec_Data[5]);

}

//// Define three-axis acceleration and
//// three-axis gyroscope variables
//// 16-bit signed integer is the data type
//int16_t ax, ay, az, gx, gy, gz;
//
//// Variable that will hold the tilt angle
//float Angle;
//
///*Angula velocity along each axis as measured by the g
// *The units are degrees per second.
// */
//float Gyro_x, Gyro_y,Gyro_z;
//
///////////////////Kalman filter////////////////
////Covariance of gyroscope noise
//float Q_angle = 0.001;
//
////Covariance of gyroscope drift noise
//float Q_gyro = 0.003;
//
////Covariance of accelerometer
//float R_angle = 0.5;
//char C_0 = 1;
//
////The filter sampling time.
//float dt = 0.005;
//
////a function containg the Kalman gain is used to calculate
////deviation of the optimal estimate.
//float K1 = 0.05;
//float K_0, K_1,t_0,t_1;
//float angle_err;
//
////Gyroscope drift
//float q_bias;
//
//float accelz = 0;
//float angle;
//float angle_speed;
//
//float Pdot[4] = {0,0,0,0};
//float P[2][2] = {{1,0},{0,1}};
//float PCt_0, PCt_1,E;


//Define three-axis acceleration, three-axis gyroscope variables
int16_t ax, ay, az, gx, gy, gz;

// The tilt angle
float Angle;

// Angular velocity along each axis as measured by the gyroscope
// The units are degrees per second.
float Gyro_x,Gyro_y,Gyro_z;

///////////////////////Kalman_Filter////////////////////////////
// Covariance of gyroscope noise
float Q_angle = 0.001;

// Covariance of gyroscope drift noise
float Q_gyro = 0.003;

// Covariance of accelerometer
float R_angle = 0.5;
char C_0 = 1;

// The filter sampling time.
float dt = 0.005;

// a function containing the Kalman gain is used to
// calculate the deviation of the optimal estimate.
float K1 = 0.05;
float K_0,K_1,t_0,t_1;
float angle_err;

// Gyroscope drift
float q_bias;

float accelz = 0;
float angle;
float angle_speed;

float Pdot[4] = { 0, 0, 0, 0};
float P[2][2] = {{ 1, 0 }, { 0, 1 }};
float  PCt_0, PCt_1, E;
//////////////////////Kalman_Filter/////////////////////////


//////////////////////Kalman Filter////////////////////

/////////////////////////////angle calculate/////////////
//void angle_calculate(int16_t ax,int16_t ay,int16_t az,int16_t gx,int16_t gy,int16_t gz,float dt,float Q_angle,float Q_gyro,float R_angle,float C_0,float K1)
//{
//	//Radial rotation angle calculation formula; negative sign is direction processing
//	Angle = -atan2(ay,az) * (180/PI);
//
//	//The X-axis angular velocity calculated by the gyroscope; the negative sign is the direction processing
//	Gyro_x = -gx/131;
//
//	//KalmanFilter
//	Kalman_Filter(Angle, Gyro_x);
//}



////////////////////////////////////////////////////////

////////////////////////////KalmanFilter//////////////////
//void Kalman_Filter(double angle_m, double gyro_m)
//{
//	//Prior estimate
//	angle += (gyro_m - q_bias) * dt;
//	angle_err = angle_m - angle;
//
//	//Differential of azimuth err covariance
//	Pdot[0] = Q_angle - P[0][1] - P[1][0];
//	Pdot[1] = -P[1][1];
//	Pdot[2] = -P[1][1];
//	Pdot[3] = Q_gyro;
//
//	//The integral of the covariance differential of the prior estimate error
//	P[0][0] += Pdot[0] * dt;
//	P[0][1] += Pdot[1] * dt;
//	P[1][0] += Pdot[2] * dt;
//	P[1][1] += Pdot[3] * dt;
//
//	//Intermediate variable of matrix multiplication
//	PCt_0 = C_0 * P[0][0];
//	PCt_1 = C_0 * P[1][0];
//
//	//Denominator
//	E = R_angle + C_0 * PCt_0;
//
//	//Gain value
//	K_0 = PCt_0 / E;
//	K_1 = PCt_1 / E;
//
//	//Intermediate variable of matrix multiplication
//	t_0 = PCt_0;
//	t_1 = C_0 * P[0][1];
//
//	//Posterior estimation error covariance
//	P[0][0] -= K_0 * t_0;
//	P[0][1] -= K_0 * t_1;
//	P[1][0] -= K_1 * t_0;
//	P[1][1] -= K_1 * t_1;
//
//	//Posterior estimation
//	q_bias += K_1 * angle_err;
//
//	//The differential value of the output value; work out the optimal angular velocity
//	angle_speed = gyro_m - q_bias;
//
//	//Posterior estimation; work out the optimal angle
//	angle += K_0 * angle_err;
//
//
//}





///////////////////////////////KalmanFilter/////////////////////
void Kalman_Filter(double angle_m, double gyro_m)
{
  // Prior estimate
  angle += (gyro_m - q_bias) * dt;
  angle_err = angle_m - angle;

  // Differential of azimuth error covariance
  Pdot[0] = Q_angle - P[0][1] - P[1][0];
  Pdot[1] = - P[1][1];
  Pdot[2] = - P[1][1];
  Pdot[3] = Q_gyro;

  // The integral of the covariance differential of the prior estimate error
  P[0][0] += Pdot[0] * dt;
  P[0][1] += Pdot[1] * dt;
  P[1][0] += Pdot[2] * dt;
  P[1][1] += Pdot[3] * dt;

  // Intermediate variable of matrix multiplication
    PCt_0 = C_0 * P[0][0];
    PCt_1 = C_0 * P[1][0];

    // Denominator
    E = R_angle + C_0 * PCt_0;

    // Gain value
    K_0 = PCt_0 / E;
    K_1 = PCt_1 / E;

    // Intermediate variable of matrix multiplication
    t_0 = PCt_0;
    t_1 = C_0 * P[0][1];

    // Posterior estimation error covariance
    P[0][0] -= K_0 * t_0;
    P[0][1] -= K_0 * t_1;
    P[1][0] -= K_1 * t_0;
    P[1][1] -= K_1 * t_1;

    // Posterior estimation
      q_bias += K_1 * angle_err;

      // The differential value of the output value; work out the optimal angular velocity
      angle_speed = gyro_m - q_bias;

      ////Posterior estimation; work out the optimal angle
      angle += K_0 * angle_err;
}


/////////////////////////////angle calculate///////////////////////
void angle_calculate(int16_t ax,int16_t ay,int16_t az,int16_t gx,int16_t gy,int16_t gz,float dt,float Q_angle,float Q_gyro,float R_angle,float C_0,float K1)
{
  // Radial rotation angle calculation formula; negative sign is direction processing
  Angle = -atan2(ay , az) * (180/ PI);

  // The X-axis angular velocity calculated by the gyroscope; the negative sign is the direction processing
  Gyro_x = -gx / 131;

  // KalmanFilter
  Kalman_Filter(Angle, Gyro_x);
}
////////////////////////////////////////////////////////////////




/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  MX_TIM15_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  /*
   * I have set the prescaler to 48 and the ARR to 100 to create a 10KHz
   * PWM signal.
   */
   HAL_TIM_PWM_Start(&htim15, TIM_CHANNEL_1); //start PWM with timer15 on channel one
   HAL_TIM_PWM_Start(&htim15, TIM_CHANNEL_2); //start PWM with timer15 on channel two

   //Timer 3 will be used to flash the led on PA0
   HAL_TIM_Base_Start_IT(&htim3);  //Start timer3 in the interrupt mode


   HAL_Delay(1000);	//delay of 2s
   MPU6050_init();	//initialise the MPU6050 sensor
   HAL_Delay(50);	//delay of 50 ms
   HAL_Delay(2000);	//delay of 2s


   HAL_UART_Transmit(&huart1,(uint8_t*) "Self Balancing Robot  MPU-6050 Initialisation starts\r\n",strlen("Self Balancing Robot  MPU-6050 Initialisation starts\r\n"),100);  	//Write the text message to the uart1

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (TRUE)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  /*Read the value from the MPU6050 and calculate the tilt angle
	   *
	   */
//	   MPU6050_ReadAllSixMotions(&ax, &ay, &az, &gx, &gy, &gz);
//	   // Radial rotation angle calculation formula;
//	   // The negative sign indicates the direction.
//	   // Convert radians to degrees.
//	   Angle = -atan2(ay , az) * (180/ PI);
//
//	   // The x-axis angular velocity calculated by the gyroscope;
//	   // The negative sign indicates the direction. The 131 value comes
//	   // from the MPU6050 datasheet.
//	   Gyro_x = -gx / 131;

	  //I2C to get MPU6050 six-axis ax,ay,az, gx,gy,gz
	  MPU6050_ReadAllSixMotions(&ax, &ay, &az, &gx, &gy, &gz);
//	  Angle = -atan2(ay , az) * (180/ PI);
//	  //
//	  //	   // The x-axis angular velocity calculated by the gyroscope;
//	  //	   // The negative sign indicates the direction. The 131 value comes
//	  //	   // from the MPU6050 datasheet.
//	  Gyro_x = -gx / 131;
//	  sprintf(uartTxBuffer,"Angle =  %.2f \t\tGyro_x =  %.2f \r\n",Angle,Gyro_x);
//	  HAL_UART_Transmit(&huart1, (uint8_t*) uartTxBuffer, sizeof(uartTxBuffer), 100);



	  //Obtain angle and Kalman Filter
	  angle_calculate(ax, ay, az, gx, gy, gz, dt, Q_angle, Q_gyro, R_angle, C_0, K1);



	   /*
	    *  Print the tilt angle in degrees and
	    *  Print the angular velocity in degrees per second
	    */
	    sprintf(uartTxBuffer,"Angle =  %.2f \t K_angle = %.2f \tGyro_x =  %.2f \t K_Gyro_x = %.2f\r\n",Angle, angle ,Gyro_x, angle_speed);
	    HAL_UART_Transmit(&huart1, (uint8_t*) uartTxBuffer, sizeof(uartTxBuffer), 100);
	    HAL_Delay(500);	//delay of 0.5s
	    /*
	     * It should be noted that when you tilt the robot backward and forth, the
	     * tilt angle and angular velocity will change accordingly.
	     * Lamek 31/08/2022
	     */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x2000090E;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 4800;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 5000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM15 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM15_Init(void)
{

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 19-1;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 100-1;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim15, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim15, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim15, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM15_Init 2 */

  /* USER CODE END TIM15_Init 2 */
  HAL_TIM_MspPostInit(&htim15);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_Pin|M1_IN1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, M1_IN2_Pin|M2_IN3_Pin|M2_IN4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_Pin M1_IN1_Pin */
  GPIO_InitStruct.Pin = LED_Pin|M1_IN1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA1 PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : M1DATA_Pin M2DATA_Pin */
  GPIO_InitStruct.Pin = M1DATA_Pin|M2DATA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : M1_IN2_Pin M2_IN3_Pin M2_IN4_Pin */
  GPIO_InitStruct.Pin = M1_IN2_Pin|M2_IN3_Pin|M2_IN4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
